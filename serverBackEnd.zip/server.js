import express, { json } from "express";
import { connect } from "./database/sqlConnection.js";
import categoryRouter from "./routes/categoryRouter.js";
import productRouter from "./routes/productRoutes.js";

import 'dotenv/config'

const PORT = process.env.PORT || 3000;
const app = express();

app.use(json());
app.use('/categories', categoryRouter)
app.use('/products', productRouter)

app.listen(PORT, () => {
  connect();
  console.log(`Servidor rodando no link http://localhost:${PORT}`);
});
